/*----------------------------------------------------------
 *				HTBLA-Leonding / Klasse: 2AHDV
 * ---------------------------------------------------------
 * Exercise Number: 0
 * Title:			chess.c
 * Author:			P. Bauer
 * Due Date:		November 03, 2010
 * ----------------------------------------------------------
 * Description:
 * Implementation of basic chess functions.
 * ----------------------------------------------------------
 */
  #include <stdlib.h>
  #include "general.h"
  #include "chess.h"

  bool 	is_square_ok (File file, Rank rank);
  int 	nr (Rank rank);
  int 	nf (File file);
  bool 	is_move_from_base_line (enum PieceColor color, Rank rank);

 bool is_piece(struct ChessPiece board ,enum PieceColor color, enum PieceType type)
 {
	return pc.color == color && pc.type == type;
 }

void init_chess_board(ChessBoard chess_board)
{
	for(size_t i = 0; i < 8; i++){
		for(size_t j = 0; j < 8; j++){
			chess_board[i][j].is_occupied = false;
		}
	}
}

struct ChessSquare* get_square(ChessBoard chess_board, int file, int rank)
{
	if(file > 'h' || file < 'a' || rank > 8 || rank < 1)
	{
		return 0;
	}
	return &chess_board[file - 'a'][rank - 1];
}

bool is_square_occupied(ChessBoard chess_board, int file, int rank)
{
	struct ChessSquare* square = get_square(chess_board, file, rank);
	if(square != 0)
	{
		return square->is_occupied;
	}
	return false;
}

bool add_piece(ChessBoard chess_board, char a, int one, struct ChessPiece piece)
{
   if((a > 'h' || a < 'a') || (one > 8 || one < 1) || chess_board[one-1][a - 97].is_occupied)
   {
     return false;
   }
   chess_board[one-1][a - 97].is_occupied = true;
   chess_board[one-1][a -97].piece = piece;
   return true;
}

ChessPiece get_piece(ChessBoard chess_board,char a, int one)
{
	struct ChessSquare* square = get_square(chess_board, file, rank);
	struct ChessPiece piece_to_return = {White, NoPiece};
	if(square == 0)
	{
		return piece_to_return;
	}
	piece_to_return.type=square->piece.type;
	piece_to_return.color=square->piece.color;
	return piece_to_return;
}

void setup_chess_board(ChessBoard chess_board)
{
      char file;
      init_chess_board(chess_board);
      for (file = 'a'; file <= 'h'; file++) 
	  {
	  		add_piece(chess_board, file, 2, {White,Pawn});
    		add_piece(chess_board, file, 7, {Black, Pawn});
      }
       add_piece(chess_board, 'a', 1, {White, Rook});
       add_piece(chess_board, 'h', 1, {White, Rook});
       add_piece(chess_board, 'b', 1, {White, Knight});
       add_piece(chess_board, 'g', 1, {White, Knight});
       add_piece(chess_board, 'c', 1, {White, Bishop});
	   add_piece(chess_board, 'f', 1, {White, Bishop});
       add_piece(chess_board, 'd', 1, {White, Queen});
       add_piece(chess_board, 'e', 1, {White, King});
       add_piece(chess_board, 'a', 8, {Black, Rook});
       add_piece(chess_board, 'h', 8, {Black, Rook});
       add_piece(chess_board, 'b', 8, {Black, Knight});
       add_piece(chess_board, 'g', 8, {Black, Knight});
       add_piece(chess_board, 'c', 8, {Black, Bishop});
       add_piece(chess_board, 'f', 8, {Black, Bishop});
       add_piece(chess_board, 'd', 8, {Black, Queen});
       add_piece(chess_board, 'e', 8, {Black, King});
}

bool remove_piece(ChessBoard chess_board, File file,Rank rank)
{
   if(file - 97 > 8 || file - 97 < 0 || rank > 8 || rank < 0 || chess_board[rank-1][file-97].is_occupied == true)
   {
     chess_board[rank-1][file - 97].is_occupied = false;
     chess_board[rank-1][file - 97].piece.type = NoPiece;
     return true;
   }
   return false;
}

bool squares_share_file(File file, Rank rank, File file02, Rank rank02)
{
   if(file > 'h' || file < 'a' || rank > 8 || rank < 1 || file02 > 'h' || file02  < 'a' || rank02 > 8 || rank02 < 1)
   {
     return false;
   }
   return(file == file02);
}

bool squares_share_rank(File file, Rank rank, File file02, Rank rank02)
{
   if(file > 'h' || file < 'a' || rank > 8 || rank < 1 || file02 > 'h' || file02  < 'a' || rank02 > 8 || rank02 < 1)
   {
     return false;
   }

   return(rank == rank02);
}

bool squares_share_diagonal(File file, Rank rank, File file02, Rank rank02)
{
   if(file > 'h' || file < 'a' || rank > 8 || rank < 1 || file02 > 'h' || file02  < 'a' || rank02 > 8 || rank02 < 1)
   {
     return false;
   }
   int dv;
   int dh;

   if(file - file02 < 0)
   {
     dv = (file - file02) * -1;
   }
   if(rank - rank02 < 0)
   {
     dh = (rank - rank02) * -1;
   }
   return dv = dh;
}

bool squares_share_knights_move(File file, Rank rank, File file02, Rank rank02)
{
   if(file > 'h' || file < 'a' || rank > 8 || rank < 1 || file02 > 'h' || file02  < 'a' || rank02 > 8 || rank02 < 1)
   {
     return false;
   }
   return ((file02 == file+1 && rank02 == rank+2) || (file02 == file-1 && rank02 == rank-2) || (file02 == file-2 && rank02 == rank-1) || (file02 == file+2 && rank02 == rank+1) || (file02 == file-1 && rank02 == rank+2) || (file02 == file+1 && rank02 == rank-2)|| (file02 == file+2 && rank02 == rank-1) || (file02 == file-2 && rank02 == rank+1));
}

bool squares_share_pawns_move (enum PieceColor color, enum MoveType move, File file, Rank rank, File file02, Rank rank02)
{
   if (move == NormalMove)
   {
     if (rank == 1 || rank == 8)
     {
       return false;
     }
     if (color == Black && rank == 7)
     {
       return ((rank02 == rank-2 && file02 == file) || (rank02 == rank-1 && file02 == file));
     }
     else if (color == White && rank == 2)
     {
       return ((rank02 == rank+2 && file02 == file) || (rank02 == rank+1 && file02 == file));
     }
     if (color == Black && rank >= 4)
     {
       return (rank02 == rank-1 && file02 == file);
     }
     else if (color == White && rank <= 4)
     {
       return (rank02 == rank+1 && file02 == file);
     }
   }
   if (move == CaptureMove)
   {
     if (color == Black)
     {
       return (file02 == file+1 && rank02 == rank-1) || (file02 == file-1 && rank02 == rank-1);
     }
     else
     {
       return (file02 == file-1 && rank02 == rank+1) || (file02 == file+1 && rank02 == rank+1);
     }
   }
	return false;
}

bool squares_share_kings_move(File file, Rank rank, File file02, Rank rank02)
{
   if(file > 'h' || file < 'a' || rank > 8 || rank < 1 || file02 > 'h' || file02  < 'a' || rank02 > 8 || rank02 < 1)
   {
     return false;
   }
   return squares_share_rank(file,rank,file02,rank02) || squares_share_file(file,rank,file02,rank02) || squares_share_diagonal(file,rank,file02,rank02);
}

bool squares_share_queens_move(File file, Rank rank, File file02, Rank rank02)
{
   if(file > 'h' || file < 'a' || rank > 8 || rank < 1 || file02 > 'h' || file02  < 'a' || rank02 > 8 || rank02 < 1)
   {
     return false;
   }
   return squares_share_rank(file,rank,file02,rank02) || squares_share_file(file,rank,file02,rank02) || squares_share_diagonal(file,rank,file02,rank02);
}